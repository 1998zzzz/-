#ifndef __LED_H
#define __LED_H
#include "stm32f10x_usart.h"
#include "sys.h"


#define D0 PCout(13)
#define LED0 PAout(8)
#define BEEP PBout(0)//������
#define BEEP1 PBout(8)//������
#define JD PBout(9)//�̵���
#define smog PBin(8)
#define fire PBin(6)

void LED_GPIO_Init(void);
void BEEP_GPIO_Init(void);

#endif
