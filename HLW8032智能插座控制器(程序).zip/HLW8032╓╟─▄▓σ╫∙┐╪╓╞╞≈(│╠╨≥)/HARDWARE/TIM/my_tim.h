#ifndef __MY_TIM_H
#define __MY_TIM_H 			   
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "LED.h"
#include "key.h"

void TIM3_Int_Init(u16 arr,u16 psc);
void TIM2_Int_Init(u16 arr,u16 psc);
extern int count;
extern int count1;
extern int count2;
extern int count3;
extern int count_10s;
extern int count_10s_flag;
extern u32 open;
extern u32 close;

#endif
