#ifndef _KEY_H
#define _KEY_H	
 
#include "sys.h"  
#include "delay.h"
#include "stm32f10x_exti.h"
#include "LED.h"
#include "oled.h"
#include "my_tim.h"

#define KEY1 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)
#define KEY2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)
#define KEY3 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)
#define KEY4 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)
#define KEY5 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)
#define FTF_PWM PBout(7)

extern u8 flag_display;//��ʾ�����־λ
extern u8 n2,n3,n4,n5,n43,n41;
extern u8 n;
extern u8 shezhi_flag;

void Key_Init(void);
void EXTIn_Init(void);

#endif 
