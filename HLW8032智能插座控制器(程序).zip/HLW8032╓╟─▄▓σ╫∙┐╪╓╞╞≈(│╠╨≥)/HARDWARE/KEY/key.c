#include "key.h"
u8 flag_display=0;
u8 n2=0,n3=0,n4=0,n5=0,n43=0,n41=0;
u8 n=0;
u8 shezhi_flag=0;
void Key_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO,ENABLE);	//��GPIO��ʱ�ӣ��ȴ򿪸��ò����޸ĸ��ù���
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);//Ҫ�ȿ�ʱ�ӣ�����ӳ�䣻����ʾ�ر�jtag��ʹ��swd��
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4;//KEY2~KEY3
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_6;//KEY4~KEY5
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;                   //KEY1
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;                   //TFT_PWM
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	FTF_PWM=1;
}
void EXTIn_Init(void)
{
	EXTI_InitTypeDef EXTI_InitStructure;  
	NVIC_InitTypeDef NVIC_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);//ʹ��AFIOʱ��
	
	//////////////////////////////////KEY1//////////////////////////////////////////////
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource15);
	EXTI_InitStructure.EXTI_Line=EXTI_Line15;
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger=EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=EXTI15_10_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority= 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority= 3;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
///////////////////////////////KEY2/////////////////////////////////////////////////	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource3);
	EXTI_InitStructure.EXTI_Line=EXTI_Line3;
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger=EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=EXTI3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority= 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority= 3;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);	
///////////////////////////////KEY3/////////////////////////////////////////////////	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource4);
	EXTI_InitStructure.EXTI_Line=EXTI_Line4;
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger=EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStructure); 
	
	NVIC_InitStructure.NVIC_IRQChannel=EXTI4_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority= 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority= 3;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
//////////////////////////////////KEY4//////////////////////////////////////////////
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource5);
	EXTI_InitStructure.EXTI_Line=EXTI_Line5;
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger=EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority= 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=3;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
//////////////////////////////////KEY5//////////////////////////////////////////////
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource6);
	EXTI_InitStructure.EXTI_Line=EXTI_Line6;
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger=EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority= 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority= 3;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);	
}
////////////////////////////////////�ⲿ�жϺ���///////////////////////////////
void EXTI15_10_IRQHandler(void)//���ܽ����л�����
{
	if(EXTI_GetITStatus(EXTI_Line15)==SET)
	{
		delay_ms(3);
		if(KEY1==0)
		{
			count_10s=0;//����رձ��⵹��ʱ�����¿�ʼ����ʱ
			FTF_PWM=1;
			count_10s_flag=1;
			if(n43==0&&n41==0)
			{
				flag_display++;
				if(flag_display>3)flag_display=0;
				switch(flag_display)
				{
					case 0:n2=0;n3=0;n4=0;n5=1;break;//��ʾ��ҳ
					case 1:n2=1;n3=0;n4=0;n5=0;break;//��ʾ��������
					case 2:n2=0;n3=1;n4=0;n5=0;break;//��ʾ��ʱ���ý���
					case 3:n2=0;n3=0;n4=1;n5=0;break;//��ʾʱ�����ý���
				}
			}			
			while(!KEY1);
		}
  } 
	EXTI_ClearITPendingBit(EXTI_Line15);
}
////////////////////////////////////////////////
void EXTI3_IRQHandler(void)          //�̵�������&&����
{
	if(EXTI_GetITStatus(EXTI_Line3)==SET)
	{
		delay_ms(5);
		if(KEY2==0)
		{
			count_10s=0;//����رձ��⵹��ʱ�����¿�ʼ����ʱ
			FTF_PWM=1;
			count_10s_flag=1;
			if(n3==0&&n4==0)
			{
				JD = ~JD;
			}
			else if(n3==2|n4==2)
			{
				shezhi_flag=1;
				n=1;
			}
			while(!KEY2);
		}
  } 
	EXTI_ClearITPendingBit(EXTI_Line3);
}
////////////////////////////////////////////////
void EXTI4_IRQHandler(void)               //����+
{
	if(EXTI_GetITStatus(EXTI_Line4)==SET)
	{
		delay_ms(5);
		if(KEY3==0)
		{
			count_10s=0;//����رձ��⵹��ʱ�����¿�ʼ����ʱ
			FTF_PWM=1;
			count_10s_flag=1;
			if(n43==1|n41==1)
			{
				shezhi_flag=1;
				n=2;
			}		
			while(!KEY3);
		}
  } 
	EXTI_ClearITPendingBit(EXTI_Line4);
}
////////////////////////////////////////////////
void EXTI9_5_IRQHandler(void)             
{
	if(EXTI_GetITStatus(EXTI_Line5)==SET)//����-
	{
		delay_ms(5);
		if(KEY4==0)
		{
			count_10s=0;//����رձ��⵹��ʱ�����¿�ʼ����ʱ
			FTF_PWM=1;
			count_10s_flag=1;
			if(n43==1|n41==1)
			{
				shezhi_flag=1;
				n=3;
			}	
			while(!KEY4);
		}
  } 
///////////////////////////////////////////////	
	else if(EXTI_GetITStatus(EXTI_Line6)==SET)//��Ļ���⿪��&&�����л�
	{
		delay_ms(5);
		if(KEY5==0)
		{
			if(n43==0&&n41==0)
			{
				FTF_PWM=~FTF_PWM;
				if(FTF_PWM==1)count_10s_flag=1;	
				else {count_10s_flag=0;count_10s=0;}
			}
			else if(n43==1|n41==1)
			{
				count_10s=0;//����رձ��⵹��ʱ�����¿�ʼ����ʱ
				FTF_PWM=1;
				count_10s_flag=1;				
				shezhi_flag=1;
				n=4;
			}
			while(!KEY5);
		}
  } 
	else;
	EXTI_ClearITPendingBit(EXTI_Line5);
	EXTI_ClearITPendingBit(EXTI_Line6);
}
