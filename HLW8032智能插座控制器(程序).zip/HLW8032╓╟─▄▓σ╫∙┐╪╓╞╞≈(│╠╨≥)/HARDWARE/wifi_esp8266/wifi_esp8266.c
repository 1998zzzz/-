#include "wifi_esp8266.h"

u8 wifi_CWMODE[]={"AT+CWMODE=3\r\n"};
u8 wifi_RST[]={"AT+RST\r\n"};
u8 wifi_CIPMUX[]={"AT+CIPMUX=1\r\n"};
u8 wifi_CIPSERVER[]={"AT+CIPSERVER=1,8888\r\n"};
u8 wifi_CWJAP[]={"AT+CWJAP=\"Bear2.4G\",\"aa17303047095\"\r\n"};
u8 wifi_ip[]={"AT+CIFSR\r\n"};

void WIFI_ESP8266(void)
{
	u8 i;
	for(i=0;i<2;i++)delay_ms(1000);
	for(i=0;i<15;i++)
	{
		USART2_Sned_Char(wifi_CWMODE[i]);		
	}
	for(i=0;i<2;i++)delay_ms(1000);
	
	for(i=0;i<10;i++)
	{
		USART2_Sned_Char(wifi_RST[i]);		
	}
	for(i=0;i<3;i++)delay_ms(1000);
	for(i=0;i<46;i++)
	{
		USART2_Sned_Char(wifi_CWJAP[i]);
	}
	for(i=0;i<7;i++)delay_ms(1000);
	for(i=0;i<15;i++)
	{
		USART2_Sned_Char(wifi_CIPMUX[i]);		
	}
	delay_ms(500);
	for(i=0;i<23;i++)
	{
		USART2_Sned_Char(wifi_CIPSERVER[i]);		
	}
	delay_ms(1000);
	for(i=0;i<13;i++)
	{
		USART2_Sned_Char(wifi_ip[i]);		
	}
	delay_ms(500);
	usart2_in=0;
	BEEP1 = 1;
	delay_ms(500);
	BEEP1 = 0;	
}
